************************************************
* Program: p2mat.exe
* Description: this program converts a POST2
*        profile to a matlab file.
************************************************

Input: a profile file with extention <filename>.prf

Output: <filename>.mat

Usage: At the command prompt Enter:
     >p2mat -r <filename> %

    where <filename> is the name of the file without
    the extention.
   
    -r  is to reverse endian.
 
    %  is for no extention on variable names for matlab.